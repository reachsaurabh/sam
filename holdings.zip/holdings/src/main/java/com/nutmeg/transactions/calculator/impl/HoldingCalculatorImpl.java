package com.nutmeg.transactions.calculator.impl;

import com.nutmeg.transactions.domain.Holding;
import com.nutmeg.transactions.domain.Transaction;
import com.nutmeg.transactions.util.CsvFileReader;

import java.io.File;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class HoldingCalculatorImpl implements HoldingCalculator {

    private CsvFileReader csvFileReader = new CsvFileReader();
    public Map<String, List<Transaction>> calculateHoldings(File transactionFile, LocalDate date) throws Exception{
        List<Holding> holdings = new ArrayList<>();
       return  csvFileReader.processInputFile(transactionFile.getPath(),date);

    }
}
