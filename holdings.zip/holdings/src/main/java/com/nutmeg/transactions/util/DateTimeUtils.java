package com.nutmeg.transactions.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class DateTimeUtils {

    public static LocalDate convertStringToDate(String dateString) {


        DateTimeFormatter formatter = DateTimeFormatter.BASIC_ISO_DATE;
        return LocalDate.parse(dateString, formatter);


    }
}
