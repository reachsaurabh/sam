package com.nutmeg.transactions.domain;

import java.time.LocalDate;

public class Transaction {

    public Holding getHolding() {
        return holding;
    }

    public void setHolding(Holding holding) {
        this.holding = holding;
    }

    public LocalDate getLocalDate() {
        return localDate;
    }

    public void setLocalDate(LocalDate localDate) {
        this.localDate = localDate;
    }

    private Holding holding;
    private LocalDate localDate;

    @Override
    public String toString() {
        return "Transaction{" +
                "holding=" + holding +
                ", localDate=" + localDate +
                '}';
    }
}
