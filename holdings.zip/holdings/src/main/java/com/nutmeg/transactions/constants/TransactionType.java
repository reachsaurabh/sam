package com.nutmeg.transactions.constants;

public interface TransactionType {

    static final String BOUGHT = "BOT";
    static final String CASH = "CASH";
}
