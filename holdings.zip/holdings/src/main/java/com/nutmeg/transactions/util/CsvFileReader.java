package com.nutmeg.transactions.util;

import com.nutmeg.transactions.constants.TransactionType;
import com.nutmeg.transactions.domain.Holding;
import com.nutmeg.transactions.domain.Transaction;

import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class CsvFileReader {


    private static final String COMMA_SEPARATOR = ",";

    public Map<String, List<Transaction>> processInputFile(String inputFilePath, LocalDate localDate) throws IOException {
        try (InputStream inputFS = new FileInputStream(inputFilePath)) {
            BufferedReader br = new BufferedReader(new InputStreamReader(inputFS));
            HashMap<String, List<Transaction>> map = new HashMap<>();
            br.lines().parallel().filter(line -> line != null && line.length() != 0).forEach(line -> {
                        Holding holding = new Holding();
                        List<Transaction> transactions = new ArrayList<>();
                        String splits[] = line.split(COMMA_SEPARATOR);
                        holding.setAsset(splits[5]);
                        holding.setHoldings(new Double(splits[3]));
                        Transaction transaction = new Transaction();
                        transaction.setHolding(holding);

                        if (map.get(splits[0]) != null) {
                            transactions = map.get(splits[0]);
                            transaction.setLocalDate(DateTimeUtils.convertStringToDate(splits[1]));
                            transactions.add(transaction);
                            map.put(splits[0], transactions);
                        } else {
                            transactions.add(transaction);
                            map.put(splits[0], transactions);
                        }
                    }

            );

            return map;

        }
    }

    private boolean isTransactionDateWithinThreshold(LocalDate transactionDate, LocalDate localDate) {
        return transactionDate.isBefore(localDate) || transactionDate.isEqual(localDate);
    }



}
