package com.netmug;

import com.nutmeg.transactions.calculator.impl.HoldingCalculator;
import com.nutmeg.transactions.calculator.impl.HoldingCalculatorImpl;
import com.nutmeg.transactions.util.DateTimeUtils;

import java.io.File;

/**
 * Hello world!
 */
public class App {
    public static void main(String[] args) throws Exception{
        System.out.println("Hello World!");
        HoldingCalculator holdingCalculator = new HoldingCalculatorImpl();
        File file = new File(args[0]);
        System.out.println(holdingCalculator.getAllTransactions(file, DateTimeUtils.convertStringToDate(args[1])));
    }
}
