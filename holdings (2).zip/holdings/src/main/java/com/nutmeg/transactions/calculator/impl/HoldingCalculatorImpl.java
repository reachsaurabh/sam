package com.nutmeg.transactions.calculator.impl;

import com.nutmeg.transactions.constants.TransactionType;
import com.nutmeg.transactions.domain.Holding;
import com.nutmeg.transactions.domain.Transaction;
import com.nutmeg.transactions.util.CsvFileReader;

import java.io.File;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HoldingCalculatorImpl implements HoldingCalculator {

    private CsvFileReader csvFileReader = new CsvFileReader();
    public Map<String, List<Transaction>> getAllTransactions(File transactionFile, LocalDate date) throws Exception {
        List<Holding> holdings = new ArrayList<>();
        return csvFileReader.processInputFile(transactionFile.getPath(), date);
    }

        public Map<String, List<Holding>> calculateHoldings(File transactionFile, LocalDate date) throws Exception {
            Map<String, List<Holding>> holdingsByAccountMap = new HashMap<>();
            Map<String, List<Transaction>> transactions = csvFileReader.processInputFile(transactionFile.getPath(), date);
            transactions.forEach((s, transaction) ->
            {
              summarizeHoldings(s,transactions,holdingsByAccountMap);
            });
return holdingsByAccountMap;
        }

    private void summarizeHoldings(String s, Map<String, List<Transaction>> transactions, Map<String, List<Holding>> holdingsByAccountMap) {
        List<Transaction> transactionList = new ArrayList<>();



        BigDecimal cashAvailable = BigDecimal.ZERO;

       for(Transaction transaction : transactionList)
       {
           TransactionType transactionType = TransactionType.valueOf(transaction.getTransactionType());
           List<Holding> holdings = new ArrayList<>();
           Holding holding = new Holding();
           holding.setAsset(transactionType.getValue());
           if(transactionType.equals(TransactionType.Cash) && transaction.getUnitPrice().equals(BigDecimal.ONE))

               cashAvailable=transaction.getHolding().getHolding();

           else if(transactionType.equals(TransactionType.Bought))
           {
               cashAvailable = cashAvailable.subtract(transaction.getHolding().getHolding());
               holding.setHoldings(transaction.getHolding().getHolding());
           }
           else if(transactionType.equals(TransactionType.Sold))
           {
               cashAvailable = cashAvailable.add(transaction.getHolding().getHolding());
               holding.setHoldings(transaction.getHolding().getHolding().negate());
           }
           else if(transactionType.equals(TransactionType.Dividend))
           {
               cashAvailable = cashAvailable.add(transaction.getHolding().getHolding());
               holding.setHoldings(transaction.getHolding().getHolding());
           }
           else if(transactionType.equals(TransactionType.Deposit))
           {
               cashAvailable = cashAvailable.add(transaction.getHolding().getHolding());
               holding.setHoldings(transaction.getHolding().getHolding());
           }

           holdings.add(holding);

           holdingsByAccountMap.

         holdingsByAccountMap.put(s,holdings);


       }

    }



}
