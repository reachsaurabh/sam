package com.nutmeg.transactions.calculator.impl;

import com.nutmeg.transactions.domain.Holding;
import com.nutmeg.transactions.domain.Transaction;

import java.io.File;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public interface HoldingCalculator {
    Map<String, List<Transaction>> getAllTransactions(File transactionFile, LocalDate date) throws Exception;
    Map<String, List<Holding>> calculateHoldings(File transactionFile, LocalDate date) throws Exception;
}
