package com.nutmeg.transactions.util;

import com.nutmeg.transactions.constants.TransactionType;
import com.nutmeg.transactions.domain.Holding;
import com.nutmeg.transactions.domain.Transaction;

import java.io.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.nutmeg.transactions.constants.TransactionType.*;

public class CsvFileReader {


    private static final String COMMA_SEPARATOR = ",";
    private static Supplier<Stream<TransactionType>> transactionTypeStream = () -> Stream.of(TransactionType.values());
    private static final Logger LOGGER = Logger.getLogger(CsvFileReader.class.getName());

    public Map<String, List<Transaction>> processInputFile(String inputFilePath, LocalDate localDate) throws IOException {
        try (InputStream inputFS = new FileInputStream(inputFilePath)) {
            BufferedReader br = new BufferedReader(new InputStreamReader(inputFS));
            HashMap<String, List<Transaction>> transactionsMap = new HashMap<>();
            br.lines().parallel().filter(line -> line != null && line.length() != 0).forEach(line -> {

                        List<Transaction> transactions = new ArrayList<>();
                        String values[] = line.split(COMMA_SEPARATOR);
                        if (validateLineRecord(values,localDate)) {
                            Transaction transaction = createTransactionRecord(values);
                            if (transactionsMap.get(values[0]) != null) {
                                transactions = transactionsMap.get(values[0]);
                                transactions.add(transaction);
                                transactionsMap.put(values[0], transactions);
                            } else {
                                transactions.add(transaction);
                                transactionsMap.put(values[0], transactions);
                            }
                        } else {
                            LOGGER.log(Level.INFO, "Skipped Line on the CSV File " + line);
                        }
                    }

            );

            return transactionsMap;

        }
    }


    private Transaction createTransactionRecord(String[] splits) {
        Transaction transaction = new Transaction();
        Holding holding = new Holding();
        holding.setAsset(splits[5]);
        holding.setHoldings(new BigDecimal(splits[3]).setScale(4, BigDecimal.ROUND_HALF_UP));
        transaction.setHolding(holding);
        transaction.setLocalDate(DateTimeUtils.convertStringToDate(splits[1]));
        transaction.setUnitPrice(new BigDecimal(splits[4]).setScale(4, RoundingMode.HALF_UP));
        transaction.setTransactionType(splits[2]);
        return transaction;
    }

    private boolean isValidTransactionType(String transTypeText) {
        return transactionTypeStream.get().filter(transactionType -> transactionType.getValue().equalsIgnoreCase(transTypeText)).findAny().isPresent();
    }

    private boolean isValidBigDecimal(String inputString) {
        boolean isValid = false;
        try {
            new BigDecimal(inputString);
            isValid = true;
        } catch (NumberFormatException nfe) {
            //log it as we have ignore the line file
            LOGGER.log(Level.INFO, "Could not parse the value as BigDecimal " + inputString);
        }
        return isValid;

    }

    private boolean validateLineRecord(String[] splits, LocalDate date) {
        if (splits.length != 6) {
            return false;
        } else if (!isValidTransactionType(splits[5]) || !isValidBigDecimal(splits[3]) || !isValidBigDecimal(splits[4]) || !DateTimeUtils.checkAsAtDate(splits[1], date))

        {
            return false;
        } else {
            return true;
        }

    }


}
