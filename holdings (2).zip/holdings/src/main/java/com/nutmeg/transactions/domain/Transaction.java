package com.nutmeg.transactions.domain;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Transaction {

    public Holding getHolding() {
        return holding;
    }

    public LocalDate getLocalDate() {
        return localDate;
    }

    public BigDecimal getUnitPrice() {
        return unitPrice;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setHolding(Holding holding) {
        this.holding = holding;
    }

    public void setLocalDate(LocalDate localDate) {
        this.localDate = localDate;
    }

    public void setUnitPrice(BigDecimal unitPrice) {
        this.unitPrice = unitPrice;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    private Holding holding;

    @Override
    public String toString() {
        return "Transaction{" +
                "holding=" + holding +
                ", localDate=" + localDate +
                ", unitPrice=" + unitPrice +
                ", transactionType='" + transactionType + '\'' +
                '}';
    }

    private LocalDate localDate;
    private BigDecimal unitPrice;
    private String transactionType;


}
