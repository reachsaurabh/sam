package com.nutmeg.transactions.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class DateTimeUtils {

    public static LocalDate convertStringToDate(String dateString) {


        DateTimeFormatter formatter = DateTimeFormatter.BASIC_ISO_DATE;
        LocalDate localDate=null;
        try {
            localDate = LocalDate.parse(dateString, formatter);
        }
        catch(DateTimeParseException dpx)
        {
            //do nothing just log it
        }

        return localDate;


    }

    public static boolean checkAsAtDate(String dateString,LocalDate dateToCompare) {



        LocalDate localDate =  convertStringToDate(dateString);
        return localDate !=null || localDate.isEqual(dateToCompare) || localDate.isBefore(dateToCompare);



    }
}
