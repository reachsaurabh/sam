package com.nutmeg.transactions.constants;

public enum TransactionType {
    Bought("BOT"),
    Sold("SLD"),
    Dividend("DIV"),
    Deposit("DEP"),
    Cash("CASH");

    private String code;

     TransactionType(String code) {
        this.code = code;
    }

    public String getValue()

    {
        return this.code;
    }

}
